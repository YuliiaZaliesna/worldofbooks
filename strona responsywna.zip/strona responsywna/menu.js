$('.nav-toggle').on('click', function(){
$('#menu').toggleClass('active');
        });