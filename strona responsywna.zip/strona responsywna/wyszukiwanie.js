function findString() {
	text=document.getElementsByName("search")[0].value;
	window.find(text);
  }